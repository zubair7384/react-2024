// import DisplayData from "./component/conditionalRendering";
// import MyButton from "./component/composition";
import MyButton from "./component/composition";
import { DerivedComponent } from "./component/inheritance";
import Flex from "./component/felx";
import CustomForm from "./component/customForm";
import "./App.css";

function App() {
  return (
    <div className="App">
      {/* <DisplayData contentType="image" />
      <MyButton /> */}
      {/* <MyButton />
      <DerivedComponent />
      <Flex>
        <h2>asdjhaskjd</h2>
      </Flex> */}
      <CustomForm />
    </div>
  );
}

export default App;
